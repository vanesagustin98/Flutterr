# QRReader APP 

Repositorio del proyecto de la aplicación de QR de mi curso de Flutter
